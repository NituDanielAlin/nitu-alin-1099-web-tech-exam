import { combineReducers } from 'redux'
import movie from './movie-reducer'
import member from './member-reducer'

export default combineReducers({
    movie, member
})