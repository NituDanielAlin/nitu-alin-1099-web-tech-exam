const INITIAL_MEMBER_STATE = {
    memberList: [],
    error: null,
    fetching: false,
    fetched: false
}

export default function reducer(state = INITIAL_MEMBER_STATE, action){
    switch (action.type) {
        case 'GET_MEMBERS_PENDING':
        case 'ADD_MEMBERS_PENDING':
        case 'EDIT_MEMBERS_PENDING':
        case 'DELETE_MEMBERS_PENDING':
            return {...state, error: null, fetching: true, fetched: false}
        case 'GET_MEMBERS_FULFILLED':
        case 'ADD_MEMBERS_FULFILLED':
        case 'EDIT_MEMBERS_FULFILLED':
        case 'DELETE_MEMBERS_FULFILLED':
            return {...state, memberList: action.payload, fetching: false, fetched: true}
        case 'GET_MEMBERS_REJECTED':
        case 'ADD_MEMBERS_REJECTED':
        case 'EDIT_MEMBERS_REJECTED':
        case 'DELETE_MEMBERS_REJECTED':
            return {...state, error: action.payload, fetching: false, fetched: false}
        default:
            return state
    }
}