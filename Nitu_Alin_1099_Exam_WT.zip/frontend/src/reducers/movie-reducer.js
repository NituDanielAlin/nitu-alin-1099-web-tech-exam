const INITIAL_STATE = {
    movieList: [],
    error: null,
    fetching: false,
    fetched: false
}

export default function reducer(state = INITIAL_STATE, action){
    switch (action.type) {
        case 'GET_MOVIES_PENDING':
        case 'ADD_MOVIES_PENDING':
        case 'EDIT_MOVIES_PENDING':
        case 'DELETE_MOVIES_PENDING':
            return {...state, error: null, fetching: true, fetched: false}
        case 'GET_MOVIES_FULFILLED':
        case 'ADD_MOVIES_FULFILLED':
        case 'EDIT_MOVIES_FULFILLED':
        case 'DELETE_MOVIES_FULFILLED':
            return {...state, movieList: action.payload, fetching: false, fetched: true}
        case 'GET_MOVIES_REJECTED':
        case 'ADD_MOVIES_REJECTED':
        case 'EDIT_MOVIES_REJECTED':
        case 'DELETE_MOVIES_REJECTED':    
            return {...state, error: action.payload, fetching: false, fetched: false}
        default:
            return state
    }
}