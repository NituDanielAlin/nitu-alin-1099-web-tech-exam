import { SERVER } from '../config/global'

export const GET_MEMBERS = 'GET_MEMBERS'
export const ADD_MEMBER = 'ADD_MEMBER'
export const EDIT_MEMBER = 'EDIT_MEMBER'
export const DELETE_MEMBER = 'DELETE_MEMBER'

export function getMembers (movieId) {
    return {
        type: GET_MEMBERS,
        payload: async () => {
            const response = await fetch(`${SERVER}/movies/${movieId}/members`)
            const data = await response.json()
            return data
        }
    }
}

export function addMember (movieId, member) {
    return {
        type: ADD_MEMBER,
        payload: async () => {
            let response = await fetch(`${SERVER}/movies/${movieId}/members`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(member)
            })
            response = await fetch(`${SERVER}/movies/${movieId}/members`)
            const data = await response.json()
            return data
        }
    }
}

export function editMember (movieId, memberId, member) {
    return {
        type: EDIT_MEMBER,
        payload: async () => {
            await fetch(`${SERVER}/movies/${movieId}/members/${memberId}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(member)
            })
            let response = await fetch(`${SERVER}/movies/${movieId}/members`)
            let data = await response.json()
            return data
        }
    }
}

export function deleteMember (movieId, memberId) {
    return {
        type: DELETE_MEMBER,
        payload: async () => {
            await fetch(`${SERVER}/movies/${movieId}/members/${memberId}`, {
                method: 'DELETE',
            })
            let response = await fetch(`${SERVER}/movies/${movieId}/members`)
            let json = await response.json()
            return json
        }
    }
}
