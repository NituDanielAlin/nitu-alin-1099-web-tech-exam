import { SERVER } from '../config/global'

export const GET_MOVIES = 'GET_MOVIES'
export const ADD_MOVIE = 'ADD_MOVIE'
export const EDIT_MOVIE = 'EDIT_MOVIE'
export const DELETE_MOVIE = 'DELETE_MOVIE'

export function getMovies () {
    return {
        type: GET_MOVIES,
        payload: async () => {
            const response = await fetch(`${SERVER}/movies`)
            const data = await response.json()
            return data
        }
    }
}

export function addMovie (movie) {
    return {
        type: ADD_MOVIE,
        payload: async () => {
            let response = await fetch(`${SERVER}/movies`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(movie)
            })
            response = await fetch(`${SERVER}/movies`)
            const data = await response.json()
            return data
        }
    }
}

export function editMovie (movieId, movie) {
    return {
        type: EDIT_MOVIE,
        payload: async () => {
            let response = await fetch(`${SERVER}/movies/${movieId}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(movie)
            })
            response = await fetch(`${SERVER}/movies`)
            const data = await response.json()
            return data
        }
    }
}

export function deleteMovie (movieId) {
    return {
        type: DELETE_MOVIE,
        payload: async () => {
            await fetch(`${SERVER}/movies/${movieId}`, {
                method: 'DELETE',
            })
            let response = await fetch(`${SERVER}/movies`)
            let json = await response.json()
            return json
        }
    }
}