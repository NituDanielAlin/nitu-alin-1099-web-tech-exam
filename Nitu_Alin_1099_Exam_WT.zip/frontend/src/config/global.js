//export const SERVER = 'http://localhost:8080'
export const SERVER = window.location.protocol + '//' + window.location.hostname +':'+window.location.port