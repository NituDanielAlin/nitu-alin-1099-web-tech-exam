import MovieEditor from './movie-editor'

function App() {
  return (
    <div>
      <MovieEditor />
    </div>
  );
}

export default App;
