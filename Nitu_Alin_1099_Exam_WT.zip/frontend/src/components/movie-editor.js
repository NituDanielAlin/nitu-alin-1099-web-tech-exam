import { useEffect, useState } from 'react'
import { useSelector, shallowEqual, useDispatch } from 'react-redux'

import { DataTable } from 'primereact/datatable'
import { Column } from 'primereact/column'
import { Button } from 'primereact/button'
import { InputText } from 'primereact/inputtext'
import { Dialog } from 'primereact/dialog'
import { Dropdown } from 'primereact/dropdown';
import { Calendar } from 'primereact/calendar';


import {movieActions} from '../actions'
import {memberActions} from '../actions'

const movieListSelector = state => state.movie.movieList
const memberListSelector = state => state.member.memberList

let movieInformation = null

function MovieEditor() {
    const [isMovieDialogShown, setIsMovieDialogShown] = useState(false)
    const [title, setTitle] = useState('')
    const [category, setCategory] = useState('')
    const [date, setDate] = useState('')
    const [isNewMovie, setIsNewMovie] = useState(true)
    const [selectedMovie, setSelectedMovie] = useState(null)
    const [isMembersDialogShown, setIsMembersDialogShown] = useState(false)
    const [name, setName] = useState('')
    const [role, setRole] = useState('')
    const [isNewMember, setIsNewMember] = useState(true)
    const [selectedMember, setSelectedMember] = useState(null)
    const [isNewMembersDialogShown, setIsNewMembersDialogShown] = useState(false)
    
    const movieList = useSelector(movieListSelector, shallowEqual)
    let memberList = useSelector(memberListSelector, shallowEqual)

    const dispatch = useDispatch()

    useEffect(() => {
        dispatch(movieActions.getMovies())
    }, [dispatch])


    const movieCategories = [
        {label: 'Science Fiction', value: 'Science Fiction'},
        {label: 'Romantic', value: 'Romantic'},
        {label: 'Action', value: 'Action'},
        {label: 'Drama', value: 'Drama'},
        {label: 'Thriller', value: 'Thriller'}
    ];

    const roles = [
        {label: 'Director', value: 'Director'},
        {label: 'Scenarist', value: 'Scenarist'},
        {label: 'Actor', value: 'Actor'},
        {label: 'Creative Director', value: 'Creative Director'}
    ];

    const addNew = () => {
        setIsMovieDialogShown(true)
        setTitle('')
        setCategory('')
        setDate('')
        setSelectedMovie(null)
        setIsNewMovie(true)
    }

    const addNewMember = () => {
        setIsMembersDialogShown(false)
        setIsNewMembersDialogShown(true)
        setName('')
        setRole('')
        setSelectedMember(null)
        setIsNewMember(true)
    }

    const showMembers = (rowdata) => {
        setIsMembersDialogShown(true)
        memberList = dispatch(memberActions.getMembers(rowdata.id))
        movieInformation = rowdata
    }

    const saveMovie = () => {
        if(isNewMovie){
            dispatch(movieActions.addMovie({title, category, date}))
        }else{
            dispatch(movieActions.editMovie(selectedMovie, {title, category, date}))
        }
        setIsMovieDialogShown(false)
        setTitle('')
        setCategory('')
        setDate('')
        setSelectedMovie(null)
    }

    const saveMember = () => {
        if(isNewMember == true){
            dispatch(memberActions.addMember(movieInformation.id, {name, role}))
        }else{
            dispatch(memberActions.editMember(movieInformation.id, selectedMember, {name, role}))
        }
        setIsNewMembersDialogShown(false)
        setName('')
        setRole('')
        setSelectedMember(null)
        movieInformation = null
    }

    const hideDialog = () => {
        setIsMovieDialogShown(false)
    }

    const hideMembersDialog = () => {
        setIsMembersDialogShown(false)
        movieInformation = null
    }

    const hideAddMemberDialog = () => {
        setIsNewMembersDialogShown(false)
        movieInformation = null
    }

    const tableFooter = (
        <div>
            <Button label='Add movie' icon='pi pi-plus' onClick={addNew}/>
        </div>
    )

    const membersTableFooter = (
        <div>
            <Button label='Add member' icon='pi pi-plus' onClick={addNewMember}/>
        </div>
    )

    const addDialogFooter = (
        <div>
            <Button label='Save' icon='pi pi-save' onClick={saveMovie}/>
        </div>
    )

    const addMemberDialogFooter = () => {
        return(
            <>
                <Button label='Save member' icon='pi pi-save' onClick={() => saveMember(movieInformation)}/>
            </>
        )
    }


    const deleteMovie = (rowData) => {
        dispatch(movieActions.deleteMovie(rowData.id))
    }

    const deleteMember = (rowData) => {
        dispatch(memberActions.deleteMember(movieInformation.id, rowData.id))
    }

    const editMovie = (rowData) => {
        setSelectedMovie(rowData.id)
        setTitle(rowData.title)
        setCategory(rowData.category)
        setDate(rowData.date)
        setIsMovieDialogShown(true)
        setIsNewMovie(false)
    }

    const editMember = (rowData) => {
        setSelectedMember(rowData.id)
        setName(rowData.name)
        setRole(rowData.role)
        setIsNewMembersDialogShown(true)
        setIsNewMember(false)
    }

    const opsColumn = (rowData) => {
        return(
            <>
                <Button icon='pi pi-times' className='p-button-danger' onClick={() => deleteMovie(rowData)} />
                <Button icon='pi pi-pencil' className='p-button-warning' onClick={() => editMovie(rowData)} />
            </>
        )
    }

    const opsMemberColumn = (rowData) => {
        return(
            <>
                <Button icon='pi pi-times' className='p-button-danger' onClick={() => deleteMember(rowData)} />
                <Button icon='pi pi-pencil' className='p-button-warning' onClick={() => editMember(rowData)} />
            </>
        )
    }

    const membersColumn = (rowData) => {
        return(
            <>
                <Button icon='pi pi-eye' className='p-button-success' onClick={() => showMembers(rowData)} />
            </>
        )
    }

    return (
      <div>
        <DataTable value={movieList} footer={tableFooter}>
            <Column header='Title' field='title' />
            <Column header='Category' field='category' />
            <Column header='Date' field='date' />
            <Column body={membersColumn} header='Crew Members'/>
            <Column body={opsColumn} />
        </DataTable>
        {
            isMovieDialogShown
                ?(
                    <Dialog visible={isMovieDialogShown} onHide={hideDialog} footer={addDialogFooter} header='Add a movie'>
                        <InputText onChange={ (evt) => setTitle(evt.target.value)} value={title} name='Movie Title' placeholder='Movie title' />
                        <Dropdown value={category} options={movieCategories} onChange={(e) => setCategory(e.value)} placeholder="Select a category"/>
                        <Calendar value={date} onChange={(e) => setDate(e.value)}></Calendar>
                    </Dialog>
                ) : null
        }

        {
            isMembersDialogShown
                ?(
                    <Dialog visible={isMembersDialogShown} onHide={hideMembersDialog} header='Crew Members of the movie'>
                        <DataTable value={memberList} footer={membersTableFooter}>
                            <Column header='Name' field='name' />
                            <Column header='Role' field='role' />
                            <Column body={opsMemberColumn} />
                        </DataTable>
                    </Dialog>
                ): null
        }

        {
            isNewMembersDialogShown
            ?(
                <Dialog visible={isNewMembersDialogShown} onHide={hideAddMemberDialog} footer={addMemberDialogFooter} header='Add a crew member'>
                    <InputText onChange={ (evt) => setName(evt.target.value)} value={name} name='Member name' placeholder='Member name' />
                    <Dropdown value={role} options={roles} onChange={(e) => setRole(e.value)} placeholder="Select a role"/>
                </Dialog>
            ) : null
        }
      </div>
    );
  }
  
  export default MovieEditor;
  