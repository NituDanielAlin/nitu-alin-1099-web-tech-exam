require('dotenv').config({})
const express= require('express')
const Sequelize = require('sequelize')
const bodyParser = require('body-parser')
const cors=require('cors')
const { Router } = require('express')
const { path } = require('path')

let sequelize

if(process.env.NODE_ENV === 'development'){
    sequelize = new Sequelize({
        dialect: 'sqlite',
        storage:"sample.db",
        define: {
            timestamps:false
        }
    })
}else{
    sequelize = new Sequelize(process.env.DATABASE_URL, {
        dialect: 'postgres',
        protocol: 'postgres',
        dialectOptions: {
            ssl: {
                require: true,
                rejectUnauthorized: false
            }
        }
    })
}

const Movie = sequelize.define('movie',{
    title: {
        type: Sequelize.STRING,
        validate: {
            len: [3, 64]
        },
        allowNull: false
    },
    category:{
        type: Sequelize.STRING,
        allowNull: false
    },
    date:{
        type: Sequelize.DATE,
        allowNull: false
    }
})

const Member = sequelize.define('member',{
    name: {
        type: Sequelize.STRING,
        validate: {
            len: [5, 64]
        },
        allowNull: false
    },
    role:{
        type: Sequelize.STRING,
        allowNull: false
    }
})

Movie.hasMany(Member)

let router = express.Router()
const app = express()
app.use(cors())
app.use(bodyParser.json())
app.use(express.static('build'))

app.get('/sync', async (req,res) =>{
    try{
        await sequelize.sync({force:true})
        res.status(201).json({message:"tables created"})
    } catch(err) {
        console.warn(err)
        res.status(500).json({message:'some error occured'})
    }
})

app.get('/movies', async (req, res) => {
    try {
        const movies = await Movie.findAll()
        res.status(200).json(movies)
    } catch (err) {
        console.warn(err)
        res.status(500).json({ message: "server error" })
    }
})

app.post('/movies', async (req, res) => {
    try {
        const movie = req.body
        await Movie.create(movie)
        res.status(201).json({message: "created"})
    } catch (err) {
        console.warn(err)
        res.status(500).json({message: "server error"})
    }
})

app.get('/movies/:mid', async(req,res) => {
    try{
        const movie = await Movie.findByPk(req.params.mid,{
            include: Member
        })
        if(movie){
            res.status(200).json(movie)
        } else{
            res.status(404).json({message:"not found"})
        }
    } catch(err) {
        console.warn(err)
        res.status(500).json({message:'server error'})
    }
})

app.put('/movies/:mid', async(req,res) => {
    try{
        const movie = await Movie.findByPk(req.params.mid)
        if(movie){
            await movie.update(req.body,{ fields: ['title','category', 'date']})
            res.status(202).json({message : "success"})
        } else{
            res.status(404).json({message:"not found"})
        }
    } catch(err) {
        console.warn(err)
        res.status(500).json({message:'server error'})
    }
})

app.delete('/movies/:mid', async(req,res) => {
    try{
        const movie = await Movie.findByPk(req.params.mid)
        if(movie){
            await movie.destroy()
            res.status(202).json({message : "deleted"})
        } else{
            res.status(404).json({message:"not found"})
        }
    } catch(err) {
        console.warn(err)
        res.status(500).json({message:'server error'})
    }
})

app.get('/movies/:mid/members',async (req,res) => {
    try{
        const movie = await Movie.findByPk(req.params.mid)
        if(movie){
            const members=await movie.getMembers()
            res.status(200).json(members)
        } else{
            res.status(404).json({message:"not found"})
        }
    } catch(err) {
        console.warn(err)
        res.status(500).json({message:'server error'})
    }
})

app.post('/movies/:mid/members',async (req,res) => {
    try{
        const movie = await Movie.findByPk(req.params.mid)
        if(movie){
            const member=req.body
            member.movieId = movie.id
            await Member.create(member)
            res.status(200).json({message: 'added'})
        } else{
            res.status(404).json({message:"not found"})
        }
    } catch(err) {
        console.warn(err)
        res.status(500).json({message:'server error'})
    }
})

app.get('/movies/:mid/members/:cid',async (req,res) => {
    try{
        const movie = await Movie.findByPk(req.params.mid)
        if(movie){
            const members= await movie.getMembers({where: {
                id:req.params.cid
            }})
            const member= members.shift()
            if(member){
                res.status(200).json(member)
            } else{
                res.status(404).json({message:"not found"})
            }
        } else{
            res.status(404).json({message:"not found"})
        }
    } catch(err) {
        console.warn(err)
        res.status(500).json({message:'server error'})
    }
})

app.put('/movies/:mid/members/:cid',async (req,res) => {
    try{
        const movie = await Movie.findByPk(req.params.mid)
        if(movie){
            const members= await movie.getMembers({where: {
                id:req.params.cid
            }})
            const member= members.shift()
            if(member){
                await member.update(req.body)
                res.status(202).json({message : "edited"})
            } else{
                res.status(404).json({message:"not found"})
            }
        } else{
            res.status(404).json({message:"not found"})
        }
    } catch(err) {
        console.warn(err)
        res.status(500).json({message:'server error'})
    }
})

app.delete('/movies/:mid/members/:cid',async (req,res) => {
    try{
        const movie = await Movie.findByPk(req.params.mid)
        if(movie){
            const members= await movie.getMembers({where: {
                id:req.params.cid
            }})
            const member= members.shift()
            if(member){
                await member.destroy()
                res.status(202).json({message : "deleted"})
            } else{
                res.status(404).json({message:"not found"})
            }
        } else{
            res.status(404).json({message:"not found"})
        }
    } catch(err) {
        console.warn(err)
        res.status(500).json({message: 'server error'})
    }
})

router.route('/').get(async (req, res) => {
    let path = path.resolve();
    res.sendFile(path.join(path, "build", "index.html"))
})

app.listen(process.env.PORT, async () => {
    await sequelize.sync({alter: true})
})